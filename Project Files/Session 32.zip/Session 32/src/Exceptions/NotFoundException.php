<?php

namespace App\Exceptions;

class NotFoundException extends \Exception
{
    
}