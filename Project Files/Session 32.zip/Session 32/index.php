<?php

require "./vendor/autoload.php";

use App\Templates\SinglePage;

$page = new SinglePage();
$page->renderPage();