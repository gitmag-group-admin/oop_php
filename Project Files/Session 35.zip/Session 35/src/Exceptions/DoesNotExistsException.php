<?php

namespace App\Exceptions;

class DoesNotExistsException extends \Exception
{
    
}