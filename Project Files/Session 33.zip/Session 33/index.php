<?php

require "./vendor/autoload.php";

use App\Templates\CategoryPage;

$page = new CategoryPage();
$page->renderPage();