<?php

function sayHello() {
    echo 'hello';
}