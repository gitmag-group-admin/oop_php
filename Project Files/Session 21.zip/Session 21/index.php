<?php

require './vendor/autoload.php';

sayHello();