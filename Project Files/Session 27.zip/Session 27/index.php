<?php

require "./vendor/autoload.php";

use App\Models\Post;
use App\Models\Setting;
use App\Models\User;

$post = new Post();
$posts = $post->filterData(function($f) {
    return str_contains($f->getTitle() , 'title');
});

dd($posts);