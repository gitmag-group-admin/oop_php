<?php

require "./vendor/autoload.php";

use App\Models\Setting;

$setting = new Setting();
dd($setting->getAllData());