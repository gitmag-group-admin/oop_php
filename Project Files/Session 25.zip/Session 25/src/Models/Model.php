<?php

namespace App\Models;

use App\Classes\Database;

abstract class Model
{
    private $database;
    protected $fileName;
    protected $entityClass;

    public function __construct()
    {
        $this->database = new Database($this->fileName, $this->entityClass);
    }

    public function getAllData()
    {
        return $this->database->getData();
    }
}