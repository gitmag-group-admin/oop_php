<?php

require "./vendor/autoload.php";

use App\Entities\PostEntity;

$postEntity = new PostEntity();
$postEntity->setId(1);
$postEntity->setTitle('title');
$postEntity->setContent('this is a test post');
$postEntity->setView(1200);
$postEntity->setImage('./images/1.jpg');
$postEntity->setDate('2022-01-01 12:15:10');

var_dump($postEntity);