<?php

require "./vendor/autoload.php";

use App\Templates\SearchPage;

$page = new SearchPage();
$page->renderPage();