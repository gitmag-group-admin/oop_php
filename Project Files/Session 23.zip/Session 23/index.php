<?php

require "./vendor/autoload.php";

use App\Classes\Database;
use App\Entities\PostEntity;
use App\Entities\SettingEntity;
use App\Entities\UserEntity;

$database = new Database('posts', PostEntity::class);
dd($database->data);