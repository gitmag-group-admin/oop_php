<?php

require "./vendor/autoload.php";

use App\Templates\MainPage;

$page = new MainPage();
$page->renderPage();
