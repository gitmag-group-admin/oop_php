<?php

require "./vendor/autoload.php";

use App\Classes\Request;

$request = new Request();
// dd($request->id);
// dd($request->getMethod());
dd($request->getUrl());