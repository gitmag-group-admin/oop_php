<?php

require './vendor/autoload.php';

use App\Test;

$test = new Test();
$test->say_hello();