<?php

namespace App;

class Test
{
    public function say_hello() {
        echo 'hello';
    }
}