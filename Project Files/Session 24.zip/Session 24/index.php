<?php

require "./vendor/autoload.php";

use App\Classes\Database;
use App\Entities\PostEntity;
use App\Entities\SettingEntity;
use App\Entities\UserEntity;

$database = new Database('posts', PostEntity::class);

$newpost = new PostEntity([
    'id' => 8,
    'title' => 'title',
    'content' => 'this is a content',
    'category' => 'social',
    'date' => date('Y-m-d H:i:s'),
    'view' => 0,
    'image' => './images/1.jpg'
]);

$database->data[] = $newpost;

$database->setData($database->data);
dd($database->data);