<?php

require "./vendor/autoload.php";

use App\Entities\PostEntity;
use App\Models\Post;
use App\Models\Setting;
use App\Models\User;

$post = new PostEntity([
    'id' => 9,
    'title' => 'title1',
    'content' => 'my content1',
    'category' => 'social',
    'view' => 100,
    'date' => date("Y-m-d H:i:s"),
    'image' => './images/1.jpg'
]);

$postModel = new Post();
$postModel->editData($post);
dd($postModel->getAllData());