<?php

require "./vendor/autoload.php";

use App\Models\Post;
use App\Models\Setting;
use App\Models\User;

$setting = new Setting();
dd($setting->getDataById(1));